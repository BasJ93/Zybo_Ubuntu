var searchData=
[
  ['optional_20functions',['Optional Functions',['../group___a_p_r___util___opt.html',1,'']]],
  ['optional_20hook_20functions',['Optional Hook Functions',['../group___a_p_r___util___o_p_t___h_o_o_k.html',1,'']]],
  ['open',['open',['../structapr__dbd__driver__t.html#a911ce972cd9c1dbbcf770aed475e6428',1,'apr_dbd_driver_t::open()'],['../structapr__dbm__type__t.html#a4695443269822d7ca9208bd6579d3635',1,'apr_dbm_type_t::open()']]]
];
