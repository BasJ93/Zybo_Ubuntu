var searchData=
[
  ['stat_20functions',['Stat Functions',['../group__apr__file__stat.html',1,'']]],
  ['shared_20memory_20routines',['Shared Memory Routines',['../group__apr__shm.html',1,'']]],
  ['signal_20handling',['Signal Handling',['../group__apr__signal.html',1,'']]],
  ['skip_20list_20implementation',['Skip list implementation',['../group__apr__skiplist.html',1,'']]],
  ['socket_20option_20definitions',['Socket option definitions',['../group__apr__sockopt.html',1,'']]],
  ['status_20value_20tests',['Status Value Tests',['../group___a_p_r___s_t_a_t_u_s___i_s.html',1,'']]],
  ['string_20routines',['String routines',['../group__apr__strings.html',1,'']]],
  ['snprintf_20implementations',['snprintf implementations',['../group___a_p_r___strings___snprintf.html',1,'']]]
];
